module.exports = {
    Candled: {
        item_name: "Candy Corn"
    },
    Submerged: {
        item_name: "Deep Sea Orb"
    },
    Reinforced: {
        item_name: "Rare Diamond"
    },
    Dirty: {
        item_name: "Dirt Bottle"
    },
    Cubic: {
        item_name: "Molten Cube"
    },
    Warped: {
        item_name: "Warped Stone"
    },
    Undead: {
        item_name: "Premium Flesh"
    },
    Rediculous: {
        item_name: "Red Nose"
    },
    Necrotic: {
        item_name: "Necromancer's Brooch"
    },
    Spiked: {
        item_name: "Dragon Scale"
    },
    Loving: {
        item_name: "Red Scarf"
    },
    Perfect: {
        item_name: "Diamond Atom"
    },
    Fabled: {
        item_name: "Dragon Claw"
    },
    Suspicious: {
        item_name: "Suspicious Vial"
    },
    Renowned: {
        item_name: "Dragon Horn"
    },
    Gilded: {
        item_name: "Midas Jewel"
    },
    Giant: {
        item_name: "Giant Tooth"
    },
    Enpowered: {
        item_name: "Sadan's Brooch"
    },
    Ancient: {
        item_name: "Precursor Gear"
    },
    Withered: {
        item_name: "Wither Blood"
    },
    Moil: {
        item_name: "Moil Log"
    },
    Blessed: {
        item_name: "Blessed Fruit"
    },
    Toil: {
        item_name: "Toil Log"
    },
    Precise: {
        item_name: "Optical Lens"
    },
    Spiritual: {
        item_name: "Spirit Stone"
    },
    Headstrong: {
        item_name: "Salmon Opal"
    },
    Fruitful: {
        item_name: "Onyx"
    },
    Magnetic: {
        item_name: "Lapis Crystal"
    },
    Fleet: {
        item_name: "Diamonite"
    },
    Mithraic: {
        item_name: "Pure Mithril"
    },
    Auspicious: {
        item_name: "Rock Gemstone"
    },
    Refined: {
        item_name: "Refined Amber"
    },
    Stellar: {
        item_name: "Petrified Starfall"
    }
}