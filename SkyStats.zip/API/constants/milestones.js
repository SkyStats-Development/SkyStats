module.exports = {
    dolphin: [250, 1000, 2500, 5000, 10000],
    rock: [2500, 7500, 20000, 100000, 250000],
    rarities: ['common', 'uncommon', 'rare', 'epic', 'legendary']
}