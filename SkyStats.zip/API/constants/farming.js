module.exports = {
  jacob_crops: {
    CARROT_ITEM: {
      name: "Carrot",
    },
    CACTUS: {
      name: "Cactus",
    },
    "INK_SACK:3": {
      name: "Cocoa Beans",
    },
    MELON: {
      name: "Melon",
    },
    MUSHROOM_COLLECTION: {
      name: "Mushroom",
    },
    NETHER_STALK: {
      name: "Nether Wart",
    },
    POTATO_ITEM: {
      name: "Potato",
    },
    PUMPKIN: {
      name: "Pumpkin",
    },
    SUGAR_CANE: {
      name: "Sugar Cane",
    },
    WHEAT: {
      name: "Wheat",
    },
  },
};
