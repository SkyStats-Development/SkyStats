const config = require('../../../../config.json')
const axios = require('axios')
const { toFixed } = require('../../../../src/contracts/helperFunctions')
const { getUUID } = require('../../../../src/contracts/API/PlayerDBAPI')
const getWoolWarsStar = require('./getWWStar')

