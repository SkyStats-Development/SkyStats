# SkyStats apis
 Bundled apis that call from skyhelper, SkyCrypt, and the Hypixel api to make my life easier
